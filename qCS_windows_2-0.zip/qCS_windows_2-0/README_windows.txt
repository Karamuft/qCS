﻿================================================================================
			           ____   ____  
			   __ _   / ___| / ___| 
			  / _` | | |     \___ \ 
			 | (_| | | |___   ___) |
			  \__, |  \____| |____/ 
			     |_|                  


       SPORT Lab, University of Southern California, Los Angeles, CA 90089 
                            http://sportlab.usc.edu/                            
                       ColdFlux Project, http://coldflux.usc.edu
							
The development is supported by                                                 
   Office of the Director of National Intelligence (ODNI),            
   Intelligence Advanced Research Projects Activity (IARPA) SuperTools program ,          
   via the U.S. Army Research Office grant W911NF-17-1-0120.          
   The views and conclusions contained herein are those of the authors and should
   not be interpreted as necessarily representing the official policies or
   endorsements, either expressed or implied, of the ODNI, IARPA, or the U.S.
   Government. The U.S. Government is authorized to reproduce and distribute
   copies for Governmental purposes notwithstanding any copyright notation herein.
							
--------------------------------------------------------------------------------

qCS is a tool to analyze and alter component values of superconducting logic cells such as RSFQ and AQFP cells.
It also helps generating critical margin/yield-optimized variants of designed cells by utilizing the following
built-in capabilities such as critical margin calculation, parametric yield analysis and critical margin range optimization.

Note:
- qCS should run on Windows OS. The current application version has been tested on Windows 10.


License:
********
Refer to the LICENSE information on the qCS user interface.


Files:
******
├── README_windows.txt: This readme file
│
└── qCS_installer.exe: An executable file for the entire tool library


Requirements:
*************
1. MATLAB Compiler Runtime (MCR) 9.11: The qCS installer will automatically download MCR from Mathworks website.
If it is already installed, the system will detect the installed path.
Minimum 2 GB of disk capacity is required to accommodate MCR installation. Any installation directory is permitted for MCR.

2. Create a parent folder for qCS installation directory since qCS deletes its parent folder upon uninstallation.


Preparation for Installation:
************
1. Extract zip file (example: "qCS_Windows_2-0.zip")
	a. R-click
	b. Extract using any installed Zip program


Installation:
************
1. Open folder which contains the installer (example: "qCS_Windows_2-0")
	a. L-click twice on "qCS_installer.exe"
	b. Click "Yes" if a permission pop-up window appears
	c. Installation wizard appears
	d. Install to any directory that does not require administrator permissions
	e. Remove the tick in the checkbox for a shortcut if it is initially selected


Permissions:
************
1. Read/Write Permissions: Make sure that the files stated below have read and write permissions on the installed
path/application directory.
	qCS.exe
	jsim.exe
	jsim_n.exe
	josim-cli.exe
	

Run:
****
1. qCS.exe is located in the installed path/application folder. Run qCS.exe to start the tool.

2. To run qCS after making sure the permissions are set, use the main executable file rather than its shortcut.
Running the app via shortcut will access to the wrong directory and the simulations will fail.
Running on the administrator for Windows OS is recommended.

3. qCS application opens after a few seconds of delay

4. qCS user guide is located under Manual Tab on qCS application.

5. To use a qCS output file as data input, in the netlist, comment out: *.FILE

 
      +------------------------------------------------------------------+
      |                             qCS 2.0                              |
      |                                                                  |
      | Copyright (C) 2021, SPORT Lab, University of Southern California |
      +------------------------------------------------------------------+


Developers:
***********
Mustafa Altay Karamuftuoglu <karamuft@usc.edu>
Haolin Cong <haolinco@usc.edu>
Massoud Pedram <pedram@usc.edu>


Questions or Bugs?
******************
You may send email to <pedram@usc.edu> for any questions you may have or bugs that you find.

================================================================================
