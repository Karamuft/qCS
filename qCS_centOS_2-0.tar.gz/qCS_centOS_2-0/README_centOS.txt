﻿================================================================================
			           ____   ____  
			   __ _   / ___| / ___| 
			  / _` | | |     \___ \ 
			 | (_| | | |___   ___) |
			  \__, |  \____| |____/ 
			     |_|                  


       SPORT Lab, University of Southern California, Los Angeles, CA 90089 
                            http://sportlab.usc.edu/                            
                       ColdFlux Project, http://coldflux.usc.edu
							
The development is supported by  
   Office of the Director of National Intelligence (ODNI),            
   Intelligence Advanced Research Projects Activity (IARPA) SuperTools program ,          
   via the U.S. Army Research Office grant W911NF-17-1-0120.          
   The views and conclusions contained herein are those of the authors and should
   not be interpreted as necessarily representing the official policies or
   endorsements, either expressed or implied, of the ODNI, IARPA, or the U.S.
   Government. The U.S. Government is authorized to reproduce and distribute
   copies for Governmental purposes notwithstanding any copyright notation herein.
							
--------------------------------------------------------------------------------

qCS is a tool to analyze and alter component values of superconducting logic cells such as RSFQ and AQFP cells.
It also helps generating critical margin/yield-optimized variants of designed cells by utilizing the following
built-in capabilities such as critical margin calculation, parametric yield analysis and critical margin range optimization.

Note:
- qCS should run on any version of Linux. The current application version has been developed and tested on CentOS 7.


License:
********
Refer to the LICENSE information on the qCS user interface.


Files:
******
├── README_centOS.txt: This readme file
│
└── qCS_installer.install: An installation file for the entire tool library


Requirements:
*************
1. Certificates: If the installer doesn't start and the error is about certificates, use the following command:
	$ sudo ln -s /etc/ssl/certs/ca-bundle.trust.crt /etc/ssl/certs/ca-certificates.crt

2. MATLAB Compiler Runtime (MCR) 9.11: The qCS installer will automatically download MCR from Mathworks website.
If it is already installed, the system will detect the installed path.
Minimum 2 GB of disk capacity is required to accommodate MCR installation. Any installation directory is permitted for MCR.

3. Create a parent folder for qCS installation directory since qCS deletes its parent folder upon uninstallation.

4. JoSIM: It is user's responsibility to satisfy JoSIM requirements (setting up the environment and installing packages).
For details, visit https://joeydelp.github.io/JoSIM/#linux


Preparation for Installation:
************
1. Extract tar.gz file
	a. R-click
	b. Open with Archive Manager
	c. Select folder
	d. L-click [Extract]
	e. Select location
	f. L-click [Extract]
	
2. Open folder (example: "qCS_CentOS_2-0")
	a. R-click "qCS_installer.install"
	b. Properties
	c. Tab: Permissions
	d. Check: Allow executing file as program
	e. Close


Installation:
************
1. Open folder which contains the installer (example: "qCS_CentOS_2-0")
	a. R-click
	b. Open Terminal
	c. $ sudo ./qCS_installer.install
	d. Installation wizard appears
	e. Install to a directory (example: /home/userName/qCS_x-x where "x-x" is the version number)


Permissions:
************
1. Read/Write Permissions: (if there is a permission restriction while trying to open or run the tool after the installation)
	a. Open Terminal on (the installed path/application)
	b. Put the following commands which will allow you to change the permissions of the files
		$ sudo chown userName qCS
		$ sudo chown userName run_qCS.sh
		$ sudo chown userName jsim
		$ sudo chown userName jsim_n
		$ sudo chown userName josim-cli
	c. Make sure that they have read and write permissions by checking their properties

2. There is an alternative method for setting the permissions altogether.
	a. Open Terminal in /userName (Home) directory
	b. Run the following command using the installation directory
		$ sudo chmod -R a+r+w+x /home/userName/qCS_x-x/ (note: "x-x" is the version number)
		or
		$ sudo chmod 777 -R /home/userName/qCS_x-x/
	If Terminal is open in the folder that contains the tool folder qCS_x-x, run the following command instead
		$ sudo chmod -R a+r+w+x qCS_x-x/
		or
		$ sudo chmod 777 -R qCS_x-x/

Run:
****
1. Go to the installed path/application folder and locate the "run_qCS.sh" file.

2. To run qCS after making sure the permissions are set, the following command will set the path to open the app.
This information is given in additional readme file located in "application" folder after the installation.
The last part of the command is the path of the installed compiler and its released version.
qCS 2.0 uses R2021b (9.11) MATLAB Runtime Version.
	$ sudo ./run_qCS.sh /usr/local/MATLAB/MATLAB_Runtime/v911
	
3. qCS application opens after a few seconds of delay

4. qCS user guide is located under Manual Tab on qCS application.

5. To use a qCS output file as data input, in the netlist, comment out: *.FILE

 
      +------------------------------------------------------------------+
      |                             qCS 2.0                              |
      |                                                                  |
      | Copyright (C) 2021, SPORT Lab, University of Southern California |
      +------------------------------------------------------------------+


Developers:
***********
Mustafa Altay Karamuftuoglu <karamuft@usc.edu>
Haolin Cong <haolinco@usc.edu>
Massoud Pedram <pedram@usc.edu>


Questions or Bugs?
******************
You may send email to <pedram@usc.edu> for any questions you may have or bugs that you find.

================================================================================
